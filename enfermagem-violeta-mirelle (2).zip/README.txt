Enfermagem — Tema Violeta Claro (Mirelle)

Conteúdo:
- index.html
- cuidados.html
- sobre.html
- contato.html
- css/style.css
- img/*.svg
- js/main.js

Como publicar no GitHub Pages:
1. Crie um repositório no GitHub (ex: username.github.io) ou em um repo normal.
2. Faça upload dos arquivos e pastas (index.html na raiz).
3. Ative o GitHub Pages nas configurações do repositório (branch: main / root).
4. Aguarde alguns minutos e abra o endereço: https://<username>.github.io/<reponame>/ (ou username.github.io para repo com esse nome).

Observações:
- As imagens são ilustrações SVG simples estilizadas para combinar com o tema violeta claro.
- O rodapé contém a assinatura: Desenvolvido por Mirelle
- Se desejar que eu faça o deploy diretamente em um repositório GitHub (com instruções de commit), me passe acesso ou o repositório (posso gerar os comandos git para você executar).
