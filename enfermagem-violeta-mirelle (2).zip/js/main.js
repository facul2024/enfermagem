
// Basic script to highlight current nav link
document.addEventListener('DOMContentLoaded', function(){
  const links = document.querySelectorAll('nav a');
  links.forEach(a=>{
    if(a.getAttribute('href') === location.pathname.split('/').pop() || (a.getAttribute('href')==='index.html' && location.pathname.endsWith('/'))){
      a.style.background='linear-gradient(90deg,#f2eaff,#f6e6ff)';
      a.style.color='var(--violet-2)';
    }
  });
});
